<?php
require_once 'config.php';

$data = json_decode(file_get_contents("php://input"));

if (!$data->client_id || !$data->content) {
    echo json_encode(["status" => "error", "message" => "Missing content"]);
    exit();
}

try {
    // Get client info first
    $stmt = $pdo->prepare("SELECT name, company, role FROM clients WHERE id = ?");
    $stmt->execute([$data->client_id]);
    $client = $stmt->fetch();

    if (!$client) {
         echo json_encode(["status" => "error", "message" => "Client not found"]);
         exit();
    }

    $stmt = $pdo->prepare("INSERT INTO testimonials (client_id, client_name, client_role, company, content, status) VALUES (?, ?, ?, ?, ?, 'pending')");
    $stmt->execute([
        $data->client_id,
        $client['name'],
        $client['role'],
        $client['company'],
        $data->content
    ]);

    echo json_encode(["status" => "success", "message" => "Experience submitted for admin review"]);
} catch (\PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Submission failed: " . $e->getMessage()]);
}
?>
